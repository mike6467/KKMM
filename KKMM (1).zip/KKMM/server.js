import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { PiSweeperBot } from './bot.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

app.use(express.json());
app.use(express.static('public'));

let botInstance = null;
let botLogs = [];
let isRunning = false;

const originalLog = console.log;
console.log = function(...args) {
    const message = args.join(' ');
    botLogs.push(message);
    if (botLogs.length > 100) {
        botLogs.shift();
    }
    originalLog.apply(console, args);
};

app.post('/api/start', async (req, res) => {
    try {
        const { targetMnemonic, sponsorMnemonic, destination, unlockTime } = req.body;

        if (!targetMnemonic || !sponsorMnemonic || !destination) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (!destination.startsWith('G') || destination.length !== 56) {
            return res.status(400).json({ error: 'Invalid destination address' });
        }

        if (unlockTime) {
            const unlockDate = new Date(unlockTime);
            if (isNaN(unlockDate.getTime())) {
                return res.status(400).json({ error: 'Invalid unlock time format' });
            }
        }

        if (isRunning) {
            return res.status(400).json({ error: 'Bot is already running' });
        }

        botLogs = [];
        botInstance = new PiSweeperBot(targetMnemonic, destination, sponsorMnemonic, unlockTime);
        isRunning = true;

        const currentBot = botInstance;
        botInstance.start().then(() => {
            if (botInstance === currentBot) {
                console.log('Bot completed');
                isRunning = false;
                botInstance = null;
            }
        }).catch(error => {
            if (botInstance === currentBot) {
                console.log(`Bot error: ${error.message}`);
                isRunning = false;
                botInstance = null;
            }
        });

        res.json({ success: true, message: 'Bot started successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/stop', (req, res) => {
    if (!isRunning || !botInstance) {
        return res.status(400).json({ error: 'Bot is not running' });
    }

    botInstance.stop();
    isRunning = false;
    
    res.json({ success: true, message: 'Bot stop signal sent' });
});

app.get('/api/status', (req, res) => {
    res.json({ running: isRunning });
});

app.get('/api/logs', (req, res) => {
    res.json({ logs: botLogs.slice(-50) });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pi Network Sweeper Bot Web Interface running on port ${PORT}`);
    console.log(`Open your browser to configure and start the bot`);
});
