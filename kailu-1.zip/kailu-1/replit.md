# Pi Network Sweeper Bot

## Overview
This is a recovery tool for Pi Network wallets that have been compromised. It helps users quickly claim and transfer claimable balances from a compromised wallet to a secure destination wallet. The bot continuously monitors for claimable balances and uses dynamic fee adjustment to compete with malicious bots.

## Project Type
- **Type**: Node.js Web Application with Bot Backend
- **Main Entry**: `server.js` (web interface) or `pi-fast.js` (CLI mode)
- **Language**: JavaScript (ES Modules)

## Key Features
- 🌐 Web interface for easy configuration - no code editing required
- 🔁 Infinite claim loop for continuous monitoring
- 🔄 Dynamic fee adjustment to compete in bidding wars
- 💸 Automatic transfer of claimed balances to safe destination wallet
- 💥 Network flooding to maximize success rate
- 🔐 Secure mnemonic-based key management (credentials stored only in memory)

## Dependencies
- `express`: Web server framework
- `dotenv`: Environment variable management
- `stellar-sdk`: Stellar blockchain SDK for Pi Network
- `bip39`: Mnemonic phrase generation/validation
- `ed25519-hd-key`: HD key derivation for Ed25519
- `node-fetch`: HTTP client for API requests

## How to Use

### Web Interface (Recommended)
1. The web interface is automatically available at port 5000
2. Open the preview in your browser
3. Fill in the required information:
   - **Compromised Wallet Passphrase**: The 12/24-word mnemonic for the wallet you want to recover funds from
   - **Sponsor Wallet Passphrase**: A secure wallet's mnemonic that will pay transaction fees
   - **Destination Address**: The Stellar address (starting with G) where recovered funds will be sent
   - **Unlock Time (Optional)**: Set a future date/time when the PI tokens will unlock. The bot will wait and automatically start claiming at that exact moment
4. Click "Start Bot" to begin monitoring and claiming balances
5. Monitor the live logs in the web interface showing countdown timer and claiming status
6. Click "Stop Bot" to stop the recovery process

### CLI Mode (Advanced)
Edit `pi-fast.js` and replace the placeholder values, then run:
```bash
npm run start:fast
```

## Security Notes
⚠️ **This tool is for recovering funds from ALREADY COMPROMISED wallets**
- Wallet credentials are stored only temporarily in memory, never on disk
- Only use this tool in a secure, trusted environment
- The tool is designed for legitimate wallet recovery purposes
- Make sure your destination wallet and sponsor wallet are secure

## Recent Changes
- 2025-11-09: Added scheduled unlock timer feature - bot now waits until specified time before claiming
- 2025-11-09: Initial import and Replit environment setup
- 2025-11-09: Added web interface for easy configuration without code editing
- 2025-11-09: Refactored bot into modular structure (bot.js, server.js)

## Architecture Notes
- Uses Stellar Horizon API at `https://api.mainnet.minepi.com`
- Implements fee bidding mechanism to compete with malicious bots
- Web server runs on port 5000 with Express.js
- Bot runs continuously in background until manually stopped
- Frontend: Simple HTML/CSS/JavaScript form
- Backend: Express.js API with bot control endpoints
