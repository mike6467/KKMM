import * as ed25519 from 'ed25519-hd-key';
import StellarSdk from 'stellar-sdk';
import * as bip39 from 'bip39';

const config = {
    horizonUrl: 'https://api.mainnet.minepi.com',
    networkPassphrase: 'Pi Network',
    baseFee: 100000,
    maxFee: 1000000,
    feePriorityMultiplier: 2.0,
    maxSubmissionAttempts: 5,
    floodCount: 3,
    floodInterval: 200,
    debug: true,
};

export class PiSweeperBot {
    constructor(targetMnemonic, destination, sponsorMnemonic, unlockTime = null) {
        this.dest = destination;
        this.targetKP = this.mnemonicToKeypair(targetMnemonic);
        this.sponsorKP = this.mnemonicToKeypair(sponsorMnemonic);
        this.server = new StellarSdk.Server(config.horizonUrl, { allowHttp: false });
        this.network = config.networkPassphrase;
        this.currentFee = config.baseFee;
        this.shouldStop = false;
        this.unlockTime = unlockTime ? new Date(unlockTime) : null;
        this.claimableUrl = `${config.horizonUrl}/claimable_balances?claimant=${this.targetKP.publicKey()}`;
        this.preBuiltTransactions = [];
        this.log(`Initialized. Check balances: ${this.claimableUrl}`);
        if (this.unlockTime) {
            this.log(`Scheduled to start at: ${this.unlockTime.toISOString()}`);
        }
    }

    stop() {
        this.log('Stop signal received, shutting down...');
        this.shouldStop = true;
    }

    log(msg) {
        if (config.debug) console.log(`[${new Date().toISOString()}] ${msg}`);
    }

    mnemonicToKeypair(mnemonic) {
        const seed = bip39.mnemonicToSeedSync(mnemonic);
        const path = "m/44'/314159'/0'";
        const { key } = ed25519.derivePath(path, seed.toString('hex'));
        return StellarSdk.Keypair.fromRawEd25519Seed(Buffer.from(key));
    }

    async getAllBalances() {
        const resp = await this.server
            .claimableBalances()
            .claimant(this.targetKP.publicKey())
            .limit(100)
            .call();
        return resp.records;
    }

    async buildTxForBalance(balanceId, amount, preFetchedSponsorAcc = null) {
        const sponsorAcc = preFetchedSponsorAcc || await this.server.loadAccount(this.sponsorKP.publicKey());
        return new StellarSdk.TransactionBuilder(sponsorAcc, {
            fee: String(this.currentFee),
            networkPassphrase: this.network,
        })
            .addOperation(StellarSdk.Operation.claimClaimableBalance({
                balanceId,
                source: this.targetKP.publicKey(),
            }))
            .addOperation(StellarSdk.Operation.payment({
                destination: this.dest,
                asset: StellarSdk.Asset.native(),
                amount: amount,
                source: this.targetKP.publicKey(),
            }))
            .setTimeout(180)
            .build();
    }

    async preBuildAndSignTransactions(balances, sponsorAcc) {
        this.preBuiltTransactions = [];
        
        for (const bal of balances) {
            const tx = await this.buildTxForBalance(bal.id, bal.amount, sponsorAcc);
            tx.sign(this.targetKP);
            tx.sign(this.sponsorKP);
            
            this.preBuiltTransactions.push({
                balanceId: bal.id,
                amount: bal.amount,
                signedXdr: tx.toXDR(),
                transaction: tx
            });
        }
        
        return this.preBuiltTransactions.length;
    }

    async start() {
        let preFetchedBalances = null;
        let preFetchedSponsorAcc = null;
        let usePreBuilt = false;
        
        if (this.unlockTime) {
            const preFetched = await this.waitUntilUnlock();
            preFetchedBalances = preFetched.balances;
            preFetchedSponsorAcc = preFetched.sponsorAcc;
            usePreBuilt = preFetched.preBuilt || false;
            if (this.shouldStop) {
                this.log('Bot stopped before unlock time');
                return;
            }
        }

        while (!this.shouldStop) {
            try {
                if (!this.unlockTime) {
                    await this.updateFeeStats();
                }
                
                if (this.shouldStop) break;
                
                const balances = preFetchedBalances || await this.getAllBalances();
                const sponsorAcc = preFetchedSponsorAcc;
                
                if (!balances.length && this.preBuiltTransactions.length === 0) {
                    this.log('No claimable balances found. Retrying immediately...');
                    continue;
                }

                if (usePreBuilt && this.preBuiltTransactions.length > 0) {
                    for (const preBuilt of this.preBuiltTransactions) {
                        if (this.shouldStop) break;
                        
                        const logMsg = `Processing balance ${preBuilt.balanceId} (${preBuilt.amount} PI)`;
                        let attempt = 0;
                        
                        while (attempt < config.maxSubmissionAttempts && !this.shouldStop) {
                            try {
                                const res = await this.server.submitTransaction(preBuilt.transaction);
                                
                                const txHash = res.hash || res.id || 'unknown';
                                const status = res.successful !== undefined ? (res.successful ? 'SUCCESS' : 'FAILED') : 'SUBMITTED';
                                this.log(logMsg);
                                this.log(`✅ ${status} - Hash: ${txHash} | Fee: ${(this.currentFee/10000000).toFixed(4)} PI (PRE-BUILT)`);
                                
                                if (res.result_xdr) {
                                    this.log(`   Result: ${res.result_xdr.substring(0, 50)}...`);
                                }

                                for (let i = 0; i < config.floodCount; i++) {
                                    setTimeout(() => {
                                        this.server.submitTransaction(preBuilt.transaction).catch(err => {
                                            this.log(`Flood ${i + 1} failed: ${err}`);
                                        });
                                    }, i * config.floodInterval);
                                }
                                break;
                            } catch (err) {
                                const errorMsg = err.response?.data?.extras?.result_codes || err.message || String(err);
                                const errorType = err.response?.status || 'Unknown';
                                
                                if (errorMsg.toString().includes('tx_bad_seq')) {
                                    this.log(`❌ Pre-built transaction has bad sequence! Rebuilding on-the-fly...`);
                                    try {
                                        const freshTx = await this.buildTxForBalance(preBuilt.balanceId, preBuilt.amount);
                                        freshTx.sign(this.targetKP);
                                        freshTx.sign(this.sponsorKP);
                                        const res = await this.server.submitTransaction(freshTx);
                                        this.log(`✅ RECOVERED - Hash: ${res.hash || res.id || 'unknown'} | Fee: ${(this.currentFee/10000000).toFixed(4)} PI (REBUILT)`);
                                        break;
                                    } catch (rebuildErr) {
                                        this.log(`❌ Rebuild failed: ${rebuildErr.message}`);
                                    }
                                }
                                
                                this.log(logMsg);
                                this.log(`❌ Attempt ${attempt + 1} FAILED [${errorType}]: ${JSON.stringify(errorMsg)}`);
                                
                                if (errorType === 429 || errorMsg.toString().includes('Too Many Requests')) {
                                    const backoffTime = Math.min(1000 * Math.pow(2, attempt), 30000);
                                    this.log(`   Rate limited! Backing off for ${backoffTime}ms...`);
                                    await new Promise(res => setTimeout(res, backoffTime));
                                }
                                
                                attempt++;
                                this.currentFee = Math.min(
                                    Math.ceil(this.currentFee * config.feePriorityMultiplier / 100) * 100,
                                    config.maxFee
                                );
                                this.log(`   Retrying with higher fee: ${(this.currentFee/10000000).toFixed(4)} PI`);
                            }
                        }
                    }
                    this.preBuiltTransactions = [];
                    usePreBuilt = false;
                    preFetchedBalances = null;
                    preFetchedSponsorAcc = null;
                    
                    this.log('All balances processed. Checking for new ones immediately...');
                    continue;
                } else {
                    for (const bal of balances) {
                        if (this.shouldStop) break;
                        
                        const id = bal.id;
                        const amt = bal.amount;
                        this.log(`Processing balance ${id} (${amt} PI)`);

                        let attempt = 0;
                        while (attempt < config.maxSubmissionAttempts && !this.shouldStop) {
                            try {
                                const tx = await this.buildTxForBalance(id, amt, sponsorAcc);
                                tx.sign(this.targetKP);
                                tx.sign(this.sponsorKP);
                                const res = await this.server.submitTransaction(tx);
                                
                                const txHash = res.hash || res.id || 'unknown';
                                const status = res.successful !== undefined ? (res.successful ? 'SUCCESS' : 'FAILED') : 'SUBMITTED';
                                this.log(`✅ ${status} - Hash: ${txHash} | Fee: ${(this.currentFee/10000000).toFixed(4)} PI`);
                                
                                if (res.result_xdr) {
                                    this.log(`   Result: ${res.result_xdr.substring(0, 50)}...`);
                                }

                                for (let i = 0; i < config.floodCount; i++) {
                                    setTimeout(() => {
                                        this.server.submitTransaction(tx).catch(err => {
                                            this.log(`Flood ${i + 1} failed: ${err}`);
                                        });
                                    }, i * config.floodInterval);
                                }
                                break;
                            } catch (err) {
                                const errorMsg = err.response?.data?.extras?.result_codes || err.message || String(err);
                                const errorType = err.response?.status || 'Unknown';
                                this.log(`❌ Attempt ${attempt + 1} FAILED [${errorType}]: ${JSON.stringify(errorMsg)}`);
                                
                                if (errorType === 429 || errorMsg.toString().includes('Too Many Requests')) {
                                    const backoffTime = Math.min(1000 * Math.pow(2, attempt), 30000);
                                    this.log(`   Rate limited! Backing off for ${backoffTime}ms...`);
                                    await new Promise(res => setTimeout(res, backoffTime));
                                }
                                
                                attempt++;
                                this.currentFee = Math.min(
                                    Math.ceil(this.currentFee * config.feePriorityMultiplier / 100) * 100,
                                    config.maxFee
                                );
                                this.log(`   Retrying with higher fee: ${(this.currentFee/10000000).toFixed(4)} PI`);
                            }
                        }
                    }
                    
                    preFetchedBalances = null;
                    preFetchedSponsorAcc = null;
                    
                    this.log('All balances processed. Checking for new ones immediately...');
                }
            } catch (e) {
                this.log(`Error in loop: ${e.message}`);
            }
        }
        this.log('Bot stopped successfully');
    }

    async waitUntilUnlock() {
        const now = new Date();
        const msUntilUnlock = this.unlockTime - now;

        if (msUntilUnlock <= 0) {
            this.log('Unlock time has already passed, starting immediately');
            this.currentFee = config.maxFee;
            const balances = await this.getAllBalances();
            const sponsorAcc = await this.server.loadAccount(this.sponsorKP.publicKey());
            const txCount = await this.preBuildAndSignTransactions(balances, sponsorAcc);
            this.log(`PRE-BUILT ${txCount} transactions for immediate submission!`);
            return { balances, sponsorAcc, preBuilt: this.preBuiltTransactions.length > 0 };
        }

        const minutes = Math.floor(msUntilUnlock / 60000);
        const seconds = Math.floor((msUntilUnlock % 60000) / 1000);
        this.log(`Waiting ${minutes}m ${seconds}s until unlock time...`);

        const checkInterval = 10000;
        const prepTime = 5000;
        let preFetchedBalances = null;
        let preFetchedSponsorAcc = null;
        
        while (new Date() < this.unlockTime && !this.shouldStop) {
            const remaining = this.unlockTime - new Date();
            const mins = Math.floor(remaining / 60000);
            const secs = Math.floor((remaining % 60000) / 1000);
            
            if (remaining <= prepTime && remaining > 500) {
                this.log(`⚡ ${secs}s - Pre-fetching EVERYTHING for instant claiming...`);
                this.currentFee = config.maxFee;
                this.log(`⚡ Using max fee: ${this.currentFee} stroops (skipping fee fetch)`);
                preFetchedBalances = await this.getAllBalances();
                preFetchedSponsorAcc = await this.server.loadAccount(this.sponsorKP.publicKey());
                
                const txCount = await this.preBuildAndSignTransactions(preFetchedBalances, preFetchedSponsorAcc);
                this.log(`✅ Found ${preFetchedBalances.length} balances! PRE-BUILT ${txCount} transactions! Ready for INSTANT claiming!`);
                
                while (new Date() < this.unlockTime && !this.shouldStop) {
                    await new Promise(resolve => setTimeout(resolve, 1));
                }
                break;
            }
            
            if (mins > 0 || secs > 30) {
                this.log(`⏰ Time until unlock: ${mins}m ${secs}s`);
            } else if (secs > 0) {
                this.log(`⏰ Time until unlock: ${secs}s`);
            }
            
            await new Promise(resolve => setTimeout(resolve, Math.min(checkInterval, remaining - prepTime)));
        }

        if (!this.shouldStop) {
            this.log('🚀 UNLOCK TIME REACHED! Starting claim process now!');
        }
        
        return { balances: preFetchedBalances, sponsorAcc: preFetchedSponsorAcc, preBuilt: this.preBuiltTransactions.length > 0 };
    }

    async updateFeeStats() {
        const stats = await this.server.feeStats();
        const p80 = parseInt(stats.fee_charged.p80, 10);
        let fee = Math.max(p80 * config.feePriorityMultiplier, config.baseFee);
        this.currentFee = Math.min(Math.ceil(fee / 100) * 100, config.maxFee);
        this.log(`Fee updated: ${this.currentFee} stroops`);
    }
}
